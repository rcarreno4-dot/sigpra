/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Integrador.ui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginFrame extends JFrame {
    public LoginFrame() {
        super("Gestion de Practicas - Inicio de sesion");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(860, 520);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new GridLayout(1, 2, 16, 0));
        root.setBackground(UITheme.BG);
        root.setBorder(BorderFactory.createEmptyBorder(22, 22, 22, 22));

        root.add(buildContextPanel());
        root.add(buildLoginPanel());

        setContentPane(root);
    }

    private JPanel buildContextPanel() {
        JPanel panel = UITheme.cardPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UITheme.BRAND);

        JLabel title = new JLabel("Contexto del sistema");
        title.setForeground(java.awt.Color.WHITE);
        title.setFont(UITheme.TITLE_FONT.deriveFont(22f));
        panel.add(title);
        panel.add(new JLabel(" "));

        panel.add(whiteLabel("Plataforma para registrar, validar y hacer seguimiento de practicas."));
        panel.add(new JLabel(" "));
        panel.add(whiteLabel("- Registro publico: solo estudiantes."));
        panel.add(whiteLabel("- Estudiante: registra practica, bitacora y evidencias."));
        panel.add(whiteLabel("- Docente: valida actividades y horas."));
        panel.add(whiteLabel("- Directora: registra docentes y aprueba cierre final."));
        return panel;
    }

    private JLabel whiteLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(UITheme.BODY_FONT);
        label.setForeground(java.awt.Color.WHITE);
        return label;
    }

    private JPanel buildLoginPanel() {
        JPanel panel = UITheme.cardPanel();
        panel.setLayout(new BorderLayout(12, 12));

        JLabel title = UITheme.titleLabel("Iniciar sesion");
        panel.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(7, 1, 0, 8));
        form.setOpaque(false);

        JTextField correo = UITheme.textField();
        JPasswordField clave = new JPasswordField();
        clave.setFont(UITheme.BODY_FONT);
        JComboBox<Role> rol = new JComboBox<>(Role.values());
        rol.setFont(UITheme.BODY_FONT);

        form.add(UITheme.bodyLabel("Correo institucional"));
        form.add(correo);
        form.add(UITheme.bodyLabel("Contrasena"));
        form.add(clave);
        form.add(UITheme.bodyLabel("Rol"));
        form.add(rol);

        JButton ingresar = UITheme.primaryButton("Ingresar");
        ingresar.addActionListener(e -> {
            String email = correo.getText().trim();
            String password = new String(clave.getPassword());
            Role selected = (Role) rol.getSelectedItem();
            if (selected == null || email.isBlank() || password.isBlank()) {
                JOptionPane.showMessageDialog(this,
                        "Completa correo, contrasena y rol.",
                        "Datos incompletos",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            AuthDao authDao = new AuthDao();
            try {
                AuthenticatedUser user = authDao.authenticate(email, password, selected).orElse(null);
                if (user == null) {
                    JOptionPane.showMessageDialog(this,
                            "Credenciales invalidas o rol incorrecto.",
                            "Acceso denegado",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }

                AppSession.setCurrentUser(user);
                switch (selected) {
                    case ESTUDIANTE -> new StudentDashboardFrame().setVisible(true);
                    case DOCENTE -> new TeacherDashboardFrame().setVisible(true);
                    case DIRECTOR -> new DirectorDashboardFrame().setVisible(true);
                }
                dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this,
                        "No fue posible conectar a Oracle.\nRevisa db.properties o variables DB_URL, DB_USER, DB_PASSWORD.\n\nDetalle: "
                                + ex.getMessage(),
                        "Error de conexion",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton registrarEstudiante = UITheme.secondaryButton("Registrarse como estudiante");
        registrarEstudiante.addActionListener(e -> {
            new StudentSelfRegistrationFrame().setVisible(true);
            dispose();
        });

        JPanel actions = new JPanel(new GridLayout(2, 1, 0, 8));
        actions.setOpaque(false);
        actions.add(ingresar);
        actions.add(registrarEstudiante);

        panel.add(form, BorderLayout.CENTER);
        panel.add(actions, BorderLayout.SOUTH);
        return panel;
    }
}
