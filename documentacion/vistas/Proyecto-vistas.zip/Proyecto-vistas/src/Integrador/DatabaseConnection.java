
package Integrador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
     private static final DatabaseConfig CONFIG = DatabaseConfig.load();
    private static final String ORACLE_DRIVER = "oracle.jdbc.OracleDriver";

    private DatabaseConnection() {
    }

    public static Connection getConnection() throws SQLException {
        ensureOracleDriverLoaded();
        return DriverManager.getConnection(CONFIG.url(), CONFIG.user(), CONFIG.password());
    }

    private static void ensureOracleDriverLoaded() throws SQLException {
        try {
            Class.forName(ORACLE_DRIVER);
        } catch (ClassNotFoundException ex) {
            throw new SQLException(
                "No se encontro el driver de Oracle JDBC en el classpath. "
                    + "Verifica que el archivo ojdbc11-21.9.0.0.jar este incluido en la carpeta app del portable.",
                ex
            );
        }
    }
}
