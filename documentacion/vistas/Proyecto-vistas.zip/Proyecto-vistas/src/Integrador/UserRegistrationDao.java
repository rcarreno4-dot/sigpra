
package Integrador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

public class UserRegistrationDao {
     private static final String SQL_INSERT_USER = """
            INSERT INTO usuario (id_usuario, nombre_completo, correo, contrasena_hash, rol, estado)
            VALUES (NULL, ?, ?, ?, ?, 'ACTIVO')
            """;

    private static final String SQL_FIND_USER_BY_EMAIL = """
            SELECT id_usuario
            FROM usuario
            WHERE LOWER(correo) = LOWER(?)
            """;

    private static final String SQL_INSERT_STUDENT = """
            INSERT INTO estudiante (id_estudiante, codigo, programa, semestre)
            VALUES (?, ?, ?, ?)
            """;

    private static final String SQL_INSERT_TEACHER = """
            INSERT INTO docente_asesor (id_docente, area)
            VALUES (?, ?)
            """;

    public void registerStudent(
            String fullName,
            String email,
            String password,
            String studentCode,
            String program,
            Integer semester
    ) throws SQLException {
        try (Connection cn = DatabaseConnection.getConnection()) {
            cn.setAutoCommit(false);
            try {
                long userId = createUser(cn, fullName, email, password, "ESTUDIANTE");
                try (PreparedStatement ps = cn.prepareStatement(SQL_INSERT_STUDENT)) {
                    ps.setLong(1, userId);
                    ps.setString(2, studentCode);
                    ps.setString(3, program);
                    if (semester == null) {
                        ps.setNull(4, Types.NUMERIC);
                    } else {
                        ps.setInt(4, semester);
                    }
                    ps.executeUpdate();
                }
                cn.commit();
            } catch (SQLException ex) {
                cn.rollback();
                throw ex;
            } finally {
                cn.setAutoCommit(true);
            }
        }
    }

    public void registerTeacher(String fullName, String email, String password, String area) throws SQLException {
        try (Connection cn = DatabaseConnection.getConnection()) {
            cn.setAutoCommit(false);
            try {
                long userId = createUser(cn, fullName, email, password, "DOCENTE");
                try (PreparedStatement ps = cn.prepareStatement(SQL_INSERT_TEACHER)) {
                    ps.setLong(1, userId);
                    ps.setString(2, area);
                    ps.executeUpdate();
                }
                cn.commit();
            } catch (SQLException ex) {
                cn.rollback();
                throw ex;
            } finally {
                cn.setAutoCommit(true);
            }
        }
    }

    private long createUser(Connection cn, String fullName, String email, String password, String role) throws SQLException {
        try (PreparedStatement ps = cn.prepareStatement(SQL_INSERT_USER)) {
            ps.setString(1, fullName);
            ps.setString(2, email);
            ps.setString(3, password);
            ps.setString(4, role);
            ps.executeUpdate();
        }
        try (PreparedStatement ps = cn.prepareStatement(SQL_FIND_USER_BY_EMAIL)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new SQLException("No fue posible recuperar el usuario creado.");
                }
                return rs.getLong("id_usuario");
            }
        }
    }
}
