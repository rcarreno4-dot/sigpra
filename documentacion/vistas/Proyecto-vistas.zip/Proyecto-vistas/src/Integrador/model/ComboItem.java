
package Integrador.model;

public record ComboItem(long id, String label) {
    @Override
    public String toString() {
        return label;
    }
}
