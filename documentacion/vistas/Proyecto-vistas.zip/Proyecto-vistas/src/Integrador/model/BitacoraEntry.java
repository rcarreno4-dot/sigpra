
package Integrador.model;

public record BitacoraEntry(String fecha, String actividad, String horas, String estado) {
}
