
package Integrador.model;


public record AuthenticatedUser(long id, String nombreCompleto, String correo, Role role) {
}
