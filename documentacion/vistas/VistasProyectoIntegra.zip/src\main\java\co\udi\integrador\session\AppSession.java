package co.udi.integrador.session;

import co.udi.integrador.model.AuthenticatedUser;

public final class AppSession {
    private static AuthenticatedUser currentUser;

    private AppSession() {
    }

    public static void setCurrentUser(AuthenticatedUser user) {
        currentUser = user;
    }

    public static AuthenticatedUser getCurrentUser() {
        return currentUser;
    }

    public static void clear() {
        currentUser = null;
    }
}
