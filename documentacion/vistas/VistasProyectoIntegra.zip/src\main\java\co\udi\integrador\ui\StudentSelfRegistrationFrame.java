package co.udi.integrador.ui;

import co.udi.integrador.data.UserRegistrationDao;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class StudentSelfRegistrationFrame extends JFrame {
    private final UserRegistrationDao registrationDao = new UserRegistrationDao();

    public StudentSelfRegistrationFrame() {
        super("Registro de Estudiante");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(760, 560);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBackground(UITheme.BG);
        root.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
        root.add(buildForm(), BorderLayout.CENTER);
        setContentPane(root);
    }

    private JPanel buildForm() {
        JPanel card = UITheme.cardPanel();
        card.setLayout(new BorderLayout(8, 8));
        card.add(UITheme.titleLabel("Autoregistro de estudiante"), BorderLayout.NORTH);

        JPanel fields = new JPanel(new GridLayout(0, 2, 8, 8));
        fields.setOpaque(false);

        JTextField txtNombre = UITheme.textField();
        JTextField txtCorreo = UITheme.textField();
        JPasswordField txtContrasena = new JPasswordField();
        txtContrasena.setFont(UITheme.BODY_FONT);
        JTextField txtCodigo = UITheme.textField();
        JTextField txtPrograma = UITheme.textField();
        JTextField txtSemestre = UITheme.textField();

        fields.add(UITheme.bodyLabel("Nombre completo"));
        fields.add(txtNombre);
        fields.add(UITheme.bodyLabel("Correo institucional"));
        fields.add(txtCorreo);
        fields.add(UITheme.bodyLabel("Contrasena"));
        fields.add(txtContrasena);
        fields.add(UITheme.bodyLabel("Codigo estudiantil"));
        fields.add(txtCodigo);
        fields.add(UITheme.bodyLabel("Programa"));
        fields.add(txtPrograma);
        fields.add(UITheme.bodyLabel("Semestre"));
        fields.add(txtSemestre);

        JPanel actions = new JPanel();
        actions.setOpaque(false);
        var btnRegister = UITheme.primaryButton("Crear cuenta de estudiante");
        btnRegister.addActionListener(e -> {
            String nombre = txtNombre.getText().trim();
            String correo = txtCorreo.getText().trim();
            String contrasena = new String(txtContrasena.getPassword());
            String codigo = txtCodigo.getText().trim();
            String programa = txtPrograma.getText().trim();
            String semestreTxt = txtSemestre.getText().trim();

            if (nombre.isBlank() || correo.isBlank() || contrasena.isBlank() || codigo.isBlank() || programa.isBlank()) {
                JOptionPane.showMessageDialog(this,
                        "Completa todos los campos obligatorios.",
                        "Registro",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            Integer semestre = null;
            if (!semestreTxt.isBlank()) {
                try {
                    semestre = Integer.parseInt(semestreTxt);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this,
                            "Semestre invalido. Usa un numero entero.",
                            "Registro",
                            JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }

            try {
                registrationDao.registerStudent(nombre, correo, contrasena, codigo, programa, semestre);
                JOptionPane.showMessageDialog(this,
                        "Registro exitoso. Ahora puedes iniciar sesion como estudiante.",
                        "Registro",
                        JOptionPane.INFORMATION_MESSAGE);
                new LoginFrame().setVisible(true);
                dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this,
                        "No se pudo registrar el estudiante.\nDetalle: " + ex.getMessage(),
                        "Error SQL",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        var btnBack = UITheme.secondaryButton("Volver a inicio");
        btnBack.addActionListener(e -> {
            new LoginFrame().setVisible(true);
            dispose();
        });

        actions.add(btnRegister);
        actions.add(btnBack);

        card.add(fields, BorderLayout.CENTER);
        card.add(actions, BorderLayout.SOUTH);
        return card;
    }
}

