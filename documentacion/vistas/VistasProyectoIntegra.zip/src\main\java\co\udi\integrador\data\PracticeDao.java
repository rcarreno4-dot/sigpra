package co.udi.integrador.data;

import co.udi.integrador.model.ComboItem;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PracticeDao {
    public record StudentProfile(long id, String nombre, String codigo, String programa) {
    }

    private static final String SQL_STUDENT_PROFILE = """
            SELECT u.id_usuario, u.nombre_completo, e.codigo, e.programa
            FROM usuario u
            JOIN estudiante e ON e.id_estudiante = u.id_usuario
            WHERE u.id_usuario = ?
            """;

    private static final String SQL_ALL_STUDENTS = """
            SELECT u.id_usuario, u.nombre_completo || ' - ' || e.codigo AS label
            FROM usuario u
            JOIN estudiante e ON e.id_estudiante = u.id_usuario
            ORDER BY u.nombre_completo
            """;

    private static final String SQL_ALL_TEACHERS = """
            SELECT u.id_usuario, u.nombre_completo AS label
            FROM usuario u
            JOIN docente_asesor d ON d.id_docente = u.id_usuario
            WHERE u.estado = 'ACTIVO'
            ORDER BY u.nombre_completo
            """;

    private static final String SQL_ALL_DIRECTORS = """
            SELECT u.id_usuario, u.nombre_completo AS label
            FROM usuario u
            JOIN director_programa d ON d.id_director = u.id_usuario
            WHERE u.estado = 'ACTIVO'
            ORDER BY u.nombre_completo
            """;

    private static final String SQL_ALL_ENTITIES = """
            SELECT id_entidad, nombre AS label
            FROM entidad_receptora
            WHERE estado = 'ACTIVA'
            ORDER BY nombre
            """;

    private static final String SQL_INSERT_PRACTICE = """
            INSERT INTO practica (
                id_practica, id_estudiante, id_docente, id_director, id_entidad,
                periodo, fecha_inicio, fecha_fin, objetivo, estado, horas_objetivo, horas_validadas
            ) VALUES (
                NULL, ?, ?, ?, ?, ?, ?, ?, ?, 'EN_CURSO', 160, 0
            )
            """;

    public StudentProfile findStudentProfile(long studentUserId) throws SQLException {
        try (Connection cn = DatabaseConnection.getConnection();
             PreparedStatement ps = cn.prepareStatement(SQL_STUDENT_PROFILE)) {
            ps.setLong(1, studentUserId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }
                return new StudentProfile(
                        rs.getLong("id_usuario"),
                        rs.getString("nombre_completo"),
                        rs.getString("codigo"),
                        rs.getString("programa")
                );
            }
        }
    }

    public List<ComboItem> listStudents() throws SQLException {
        return listCombo(SQL_ALL_STUDENTS);
    }

    public List<ComboItem> listTeachers() throws SQLException {
        return listCombo(SQL_ALL_TEACHERS);
    }

    public List<ComboItem> listDirectors() throws SQLException {
        return listCombo(SQL_ALL_DIRECTORS);
    }

    public List<ComboItem> listEntities() throws SQLException {
        return listCombo(SQL_ALL_ENTITIES);
    }

    public void createPractice(long studentId, long teacherId, long directorId, long entityId,
                               String periodo, LocalDate fechaInicio, LocalDate fechaFin, String objetivo)
            throws SQLException {
        try (Connection cn = DatabaseConnection.getConnection();
             PreparedStatement ps = cn.prepareStatement(SQL_INSERT_PRACTICE)) {
            ps.setLong(1, studentId);
            ps.setLong(2, teacherId);
            ps.setLong(3, directorId);
            ps.setLong(4, entityId);
            ps.setString(5, periodo);
            ps.setDate(6, Date.valueOf(fechaInicio));
            ps.setDate(7, Date.valueOf(fechaFin));
            ps.setString(8, objetivo);
            ps.executeUpdate();
        }
    }

    private List<ComboItem> listCombo(String sql) throws SQLException {
        List<ComboItem> items = new ArrayList<>();
        try (Connection cn = DatabaseConnection.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                items.add(new ComboItem(rs.getLong(1), rs.getString(2)));
            }
        }
        return items;
    }
}
