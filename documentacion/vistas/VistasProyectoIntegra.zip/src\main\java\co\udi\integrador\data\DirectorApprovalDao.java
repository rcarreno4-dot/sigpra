package co.udi.integrador.data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class DirectorApprovalDao {
    private static final String SQL_PENDING = """
            SELECT p.id_practica,
                   u.nombre_completo AS estudiante,
                   p.periodo,
                   TO_CHAR(p.horas_validadas) || '/' || TO_CHAR(p.horas_objetivo) AS avance_horas,
                   TO_CHAR(p.fecha_registro, 'YYYY-MM-DD') AS fecha_registro
            FROM practica p
            JOIN usuario u ON u.id_usuario = p.id_estudiante
            WHERE p.id_director = ?
              AND p.estado = 'PENDIENTE_APROBACION'
            ORDER BY p.fecha_registro DESC, p.id_practica DESC
            """;

    private static final String SQL_APPROVE = """
            UPDATE practica
            SET estado = 'FINALIZADA',
                id_director_aprueba = ?,
                fecha_aprobacion = SYSTIMESTAMP,
                observacion_director_cierre = ?
            WHERE id_practica = ?
            """;

    private static final String SQL_RETURN_TRACKING = """
            UPDATE practica
            SET estado = 'EN_CURSO',
                id_director_aprueba = NULL,
                fecha_aprobacion = NULL,
                observacion_director_cierre = ?
            WHERE id_practica = ?
            """;

    public DefaultTableModel listPendingApprovals(long directorId) throws SQLException {
        DefaultTableModel model = new DefaultTableModel(
                new String[]{"ID Practica", "Estudiante", "Periodo", "Horas", "Fecha registro"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        try (Connection cn = DatabaseConnection.getConnection();
             PreparedStatement ps = cn.prepareStatement(SQL_PENDING)) {
            ps.setLong(1, directorId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                            rs.getLong("id_practica"),
                            rs.getString("estudiante"),
                            rs.getString("periodo"),
                            rs.getString("avance_horas"),
                            rs.getString("fecha_registro")
                    });
                }
            }
        }
        return model;
    }

    public void approveClosure(long practiceId, long directorId, String observation) throws SQLException {
        try (Connection cn = DatabaseConnection.getConnection();
             PreparedStatement ps = cn.prepareStatement(SQL_APPROVE)) {
            ps.setLong(1, directorId);
            ps.setString(2, observation);
            ps.setLong(3, practiceId);
            ps.executeUpdate();
        }
    }

    public void returnToTracking(long practiceId, String observation) throws SQLException {
        try (Connection cn = DatabaseConnection.getConnection();
             PreparedStatement ps = cn.prepareStatement(SQL_RETURN_TRACKING)) {
            ps.setString(1, observation);
            ps.setLong(2, practiceId);
            ps.executeUpdate();
        }
    }
}

